import React, { useState, useEffect } from 'react';
import { Button, Image, View, Platform, Text } from 'react-native';
import Camera from './camera'
import Data from '../dados'
export default function Editar() {


    return (
        <View>
            <Text style={{color: 'white'}}>Teste</Text>
            <Camera />
        </View>
    );
}