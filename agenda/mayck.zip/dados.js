
export let DATA = [
    {
        id: [0],
        nome: 'Mayck',
        data: ['17 98809 0058'],
        img: require('./assets/mayck.png'),
        apelido: 'May_Edu',
        email: 'mayck22.03@hotmail.com',
        local: 'Votuporanga - SP',
        info: 'Se quiser sim mn'
    },
    {
        id: [1],
        nome: 'Erick Beran',
        data: ['17 98171 8722'],
        img: require('./assets/erick.png'),
        apelido: '?',
        email: 'beran@email.com',
        local: 'Votuporanga - SP',
        info: 'ok'
    },
    {
        id: [2],
        nome: 'Felipe Moraes',
        data: ['17 98227 6773'],
        img: require('./assets/moraes.png'),
        apelido: 'Moraes',
        email: 'moraes@email.com',
        local: 'Votuporanga - SP',
        info: 'i'
    },
    {
        id: [3],
        nome: 'João Pedro',
        data: ['17 99150 8653'],
        img: require('./assets/jp.png'),
        apelido: 'Jão',
        email: 'jp@email.com',
        local: 'Votuporanga - SP',
        info: 'jp'
    },
    {
        id: [4],
        nome: 'João Victor',
        data: ['17 99123 7982'],
        img: require('./assets/jv.png'),
        apelido: 'casca de bala',
        email: 'jv@email.com',
        local: 'Votuporanga - SP',
        info: 'Um casca de bala'
    },
];

